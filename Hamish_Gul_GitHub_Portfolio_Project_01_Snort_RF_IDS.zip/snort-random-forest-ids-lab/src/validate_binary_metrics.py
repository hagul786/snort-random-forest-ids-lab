#!/usr/bin/env python3
"""Recalculate the reported binary metrics from TN/FP/FN/TP."""
TN, FP, FN, TP = 418_992, 305, 427, 84_749

def safe_div(a, b):
    return a / b if b else 0.0

accuracy = safe_div(TP + TN, TP + TN + FP + FN)
precision = safe_div(TP, TP + FP)
recall = safe_div(TP, TP + FN)
f1 = safe_div(2 * precision * recall, precision + recall)

print(f"Records:   {TP + TN + FP + FN:,}")
print(f"TN/FP/FN/TP: {TN:,} / {FP:,} / {FN:,} / {TP:,}")
print(f"Accuracy:  {accuracy * 100:.4f}%")
print(f"Precision: {precision * 100:.4f}%")
print(f"Recall:    {recall * 100:.4f}%")
print(f"F1-score:  {f1 * 100:.4f}%")
