#!/usr/bin/env python3
"""Leakage-aware Random Forest baseline for CICIDS2017.

This public portfolio version intentionally splits before fitting median imputation.
It is therefore methodologically safer than the historical academic preprocessing,
and fresh metrics are not expected to be numerically identical to the dissertation.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import joblib
import matplotlib.pyplot as plt
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score

def load_dataset(dataset_dir: Path, sample_frac: float | None) -> pd.DataFrame:
    files = sorted(dataset_dir.glob("*.csv"))
    if not files:
        raise FileNotFoundError(f"No CSV files found in {dataset_dir}")
    frames = []
    for path in files:
        df = pd.read_csv(path, low_memory=False)
        df.columns = df.columns.str.strip()
        frames.append(df)
        print(f"Loaded {path.name}: {len(df):,} rows")
    df = pd.concat(frames, ignore_index=True)
    if sample_frac is not None:
        if not 0 < sample_frac <= 1:
            raise ValueError("--sample-frac must be in (0, 1]")
        df = df.sample(frac=sample_frac, random_state=42)
        print(f"Sampled to {len(df):,} rows")
    return df

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset_dir", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("results/run1"))
    parser.add_argument("--sample-frac", type=float, default=None)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    df = load_dataset(args.dataset_dir, args.sample_frac)
    raw_rows = len(df)
    df = df.drop_duplicates().copy()
    print(f"Removed {raw_rows - len(df):,} duplicates")

    if "Label" not in df.columns:
        raise KeyError("Expected a Label column")
    y_text = df.pop("Label").astype(str).str.strip()
    X = df.select_dtypes(include=[np.number]).replace([np.inf, -np.inf], np.nan)
    print(f"Numerical features: {X.shape[1]}")

    encoder = LabelEncoder()
    y = encoder.fit_transform(y_text)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, stratify=y, random_state=42
    )

    # Critical: fit medians on TRAINING DATA ONLY.
    imputer = SimpleImputer(strategy="median")
    X_train_i = imputer.fit_transform(X_train)
    X_test_i = imputer.transform(X_test)

    model = RandomForestClassifier(
        n_estimators=100, criterion="gini", max_depth=None,
        min_samples_split=2, min_samples_leaf=1, max_features="sqrt",
        bootstrap=True, class_weight=None, random_state=42, n_jobs=-1
    )
    model.fit(X_train_i, y_train)
    pred = model.predict(X_test_i)

    acc = accuracy_score(y_test, pred)
    macro_f1 = f1_score(y_test, pred, average="macro", zero_division=0)
    weighted_f1 = f1_score(y_test, pred, average="weighted", zero_division=0)
    report = classification_report(y_test, pred, target_names=encoder.classes_, zero_division=0, output_dict=True)
    cm = confusion_matrix(y_test, pred)

    metrics = {
        "raw_rows_after_optional_sampling": raw_rows,
        "clean_rows_after_duplicate_removal": len(X),
        "training_rows": len(X_train),
        "testing_rows": len(X_test),
        "numerical_features": X.shape[1],
        "accuracy": acc,
        "macro_f1": macro_f1,
        "weighted_f1": weighted_f1,
        "note": "Leakage-aware public portfolio run; may differ from historical dissertation metrics."
    }
    (args.output_dir / "metrics.json").write_text(json.dumps(metrics, indent=2))
    (args.output_dir / "classification_report.json").write_text(json.dumps(report, indent=2))
    np.savetxt(args.output_dir / "confusion_matrix.csv", cm, fmt="%d", delimiter=",")
    joblib.dump({"model": model, "imputer": imputer, "label_encoder": encoder, "features": list(X.columns)}, args.output_dir / "rf_pipeline.joblib")

    fig, ax = plt.subplots(figsize=(10, 8))
    image = ax.imshow(cm)
    ax.set_title("Random Forest confusion matrix")
    ax.set_xlabel("Predicted class index")
    ax.set_ylabel("True class index")
    fig.colorbar(image, ax=ax)
    fig.tight_layout()
    fig.savefig(args.output_dir / "confusion_matrix.png", dpi=180)
    plt.close(fig)

    print(json.dumps(metrics, indent=2))

if __name__ == "__main__":
    main()
