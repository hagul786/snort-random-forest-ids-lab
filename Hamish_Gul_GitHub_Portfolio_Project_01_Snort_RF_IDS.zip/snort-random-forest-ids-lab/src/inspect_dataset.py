#!/usr/bin/env python3
"""Quick inventory of CICIDS2017 MachineLearningCVE CSV files."""
from __future__ import annotations
import argparse
from pathlib import Path
import pandas as pd

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset_dir", type=Path)
    args = parser.parse_args()
    files = sorted(args.dataset_dir.glob("*.csv"))
    if not files:
        raise SystemExit("No CSV files found")
    total = 0
    labels = {}
    for path in files:
        df = pd.read_csv(path, low_memory=False)
        df.columns = df.columns.str.strip()
        total += len(df)
        if "Label" in df.columns:
            for label, n in df["Label"].astype(str).str.strip().value_counts().items():
                labels[label] = labels.get(label, 0) + int(n)
        print(f"{path.name}: {len(df):,} rows, {len(df.columns)} columns")
    print(f"\nFiles: {len(files)}")
    print(f"Raw rows: {total:,}")
    if labels:
        print("\nTop labels:")
        for label, n in sorted(labels.items(), key=lambda x: x[1], reverse=True)[:20]:
            print(f"  {label}: {n:,}")

if __name__ == "__main__":
    main()
