#!/usr/bin/env python3
"""Count the three portfolio Snort alert messages in an alert_fast log."""
from __future__ import annotations
import argparse
from pathlib import Path

MESSAGES = {
    "icmp": "ICMP Echo Request",
    "syn": "Possible TCP SYN Scan",
    "ssh": "SSH Connection Attempt",
}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("logfile", type=Path)
    args = parser.parse_args()
    text = args.logfile.read_text(errors="replace")
    counts = {name: text.count(msg) for name, msg in MESSAGES.items()}
    counts["total_selected"] = sum(counts.values())
    for key, value in counts.items():
        print(f"{key}: {value}")

if __name__ == "__main__":
    main()
