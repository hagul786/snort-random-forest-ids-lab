# Security and Responsible Use

This repository is for defensive education and authorised laboratory testing.

- Do not run scans or probes against systems without explicit permission.
- Do not commit credentials, private logs, personal data, full university submissions or employer-confidential material.
- The included Snort rules are simple laboratory examples and are not a production security policy.
- The Random Forest workflow is a research baseline, not a production detector.
