# Snort 3 + Random Forest Intrusion Detection Lab

A portfolio version of an MSc intrusion-detection project comparing **Snort 3 live rule response** with **Random Forest offline flow classification**.

> **Scope:** This repository demonstrates two separate evidence paths. It does **not** claim a packet-for-packet benchmark, proven zero-day detection, or a validated hybrid IDS.

## Why this project matters

Signature-based and machine-learning IDS approaches operate differently. Snort inspects live packets and produces rule alerts, while the Random Forest workflow classifies labelled network-flow records. This project shows how to evaluate both without forcing unlike outputs into a misleading single score.

## Architecture

```mermaid
flowchart LR
    K[Kali Linux
192.168.10.30] --> V[VirtualBox Host-Only Network]
    V --> U[Ubuntu IDS Server
192.168.10.10]
    U --> S[Snort 3
Live rule response]

    C[CICIDS2017 CSV files] --> P[Leakage-aware preprocessing]
    P --> R[Random Forest
Offline classification]

    S --> O[Operational comparison]
    R --> O
    O --> H[Proposed future hybrid / SIEM correlation]
```

## Reported academic results

The original academic experiment reported:

- Snort alerts: **1,035** across three controlled scenarios
  - ICMP: 20
  - TCP SYN: 1,007 packet-level alerts from **one** scan
  - SSH: 8 alerts from 10 connection attempts
- Random Forest test records: **504,473**
- Multiclass accuracy: **99.8238%**
- Weighted F1: **99.8219%**
- Macro F1: **87.7974%**
- Binary confusion matrix: TN 418,992 / FP 305 / FN 427 / TP 84,749
- Binary F1: **99.5700%**

The important interpretation is that **1,007 SYN alerts are not 1,007 attacks**. They are packet-level rule responses from one scan. Likewise, high aggregate Random Forest performance did not eliminate minority-class weaknesses.

## Public-repository correction

The academic pipeline identified a preprocessing limitation: median imputation was calculated before the train/test split. This public portfolio implementation uses a **split-first, train-only imputation workflow** to avoid that leakage path. Therefore, a fresh retraining run may produce metrics that differ from the historical dissertation figures above.

## Repository structure

```text
snort-random-forest-ids-lab/
├── README.md
├── LICENSE
├── SECURITY.md
├── requirements.txt
├── .gitignore
├── data/
│   └── README.md
├── docs/
│   ├── architecture.md
│   └── interview_talking_points.md
├── examples/
│   └── illustrative_alerts.log
├── results/
│   └── reported_metrics.json
├── snort/
│   └── local.rules
└── src/
    ├── count_snort_alerts.py
    ├── inspect_dataset.py
    ├── train_rf_leakage_free.py
    └── validate_binary_metrics.py
```

## Snort lab

### Validate configuration

```bash
snort -V
snort -c /usr/local/etc/snort/snort.lua -T
```

### Start live monitoring

```bash
sudo snort -c /usr/local/etc/snort/snort.lua -i enp0s3 -A alert_fast -l ./logs
```

### Generate controlled traffic from Kali

Use only in an isolated lab you own or are authorised to test.

```bash
ping -c 20 192.168.10.10
sudo nmap -sS 192.168.10.10
for i in {1..10}; do nc -vz 192.168.10.10 22; done
```

### Count alerts

```bash
python src/count_snort_alerts.py ./logs/alert_fast.txt
```

## Random Forest workflow

### 1. Create a virtual environment

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Add CICIDS2017 locally

Place the eight MachineLearningCVE CSV files in a local directory. **Do not commit the dataset to GitHub.** See `data/README.md`.

### 3. Inspect the dataset

```bash
python src/inspect_dataset.py /path/to/MachineLearningCVE
```

### 4. Train the leakage-aware baseline

```bash
python src/train_rf_leakage_free.py /path/to/MachineLearningCVE --output-dir results/run1
```

For a quick portfolio test on a smaller fraction:

```bash
python src/train_rf_leakage_free.py /path/to/MachineLearningCVE --sample-frac 0.05 --output-dir results/demo
```

### 5. Reproduce the historical binary metrics from the reported confusion matrix

```bash
python src/validate_binary_metrics.py
```

## What I learned

- Alert counts must not be confused with independent attacks.
- Accuracy alone can hide minority-class weaknesses.
- Weighted and macro F1 answer different questions.
- A fair Snort-vs-ML comparison requires common labelled traffic if direct ranking is the goal.
- A proposed hybrid architecture is not the same as a validated operational system.
- Reproducibility includes reporting preprocessing limitations, not only successful results.

## Future work

- Common labelled packet traffic for both systems
- Live flow extraction for the ML model
- Event-level Snort alert aggregation
- SIEM correlation and analyst workflow testing
- Cross-dataset validation (for example CIC-IDS2018 / UNSW-NB15)
- Resource benchmarking: latency, throughput, CPU and memory
- Class weighting and alternative tree models such as XGBoost / LightGBM

## Ethics and safety

All active security testing should be performed only on systems you own or have explicit permission to test. This repository is intended for defensive learning and authorised laboratory use.
