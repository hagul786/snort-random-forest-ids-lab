# Dataset directory

This repository does not redistribute CICIDS2017.

Download the dataset from its legitimate source and keep the MachineLearningCVE CSV files outside version control. Pass that directory path to the scripts in `src/`.

Expected academic run:
- 8 CSV files
- 2,830,743 raw records before duplicate removal
- 2,522,362 cleaned records in the reported academic preprocessing

Fresh runs may differ if the source files or preprocessing implementation differ.
