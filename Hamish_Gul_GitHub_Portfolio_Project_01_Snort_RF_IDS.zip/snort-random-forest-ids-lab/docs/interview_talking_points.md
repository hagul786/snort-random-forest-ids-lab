# Interview Talking Points

## 30-second project explanation

I built an isolated VirtualBox IDS lab using Kali Linux and Ubuntu. I configured Snort 3 for live ICMP, SYN-scan and SSH rule-response testing, and separately evaluated a Random Forest classifier on CICIDS2017. The key part of the project was not just getting high numbers; I focused on interpretation, including alert duplication, minority-class recall, false positives/negatives, data leakage risk and the limits of comparing unlike IDS evidence.

## Strong technical points

- Snort was validated with `snort -T` before testing.
- One Nmap SYN scan generated many packet-level alerts; those alerts were not treated as separate attacks.
- Random Forest aggregate performance was strong, but macro F1 and minority recall showed uneven class behaviour.
- The public portfolio uses split-first imputation to avoid the leakage path identified in the academic implementation.
- The hybrid IDS is a proposed design, not a claimed production system.

## If asked what you would improve

Use the same labelled traffic for both systems, extract flows live, aggregate Snort packets into events, add SIEM correlation, evaluate repeated trials and confidence intervals, and measure latency/CPU/memory/throughput.
