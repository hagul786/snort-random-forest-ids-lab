# Architecture and Evaluation Boundaries

## Live signature path

Kali Linux generated controlled traffic across a VirtualBox Host-Only network to an Ubuntu IDS server running Snort 3. The reported scenarios were ICMP Echo Request, TCP SYN scanning and SSH connection attempts.

## Offline machine-learning path

The Random Forest model used CICIDS2017 flow records. This is a separate offline evaluation path, not a live classifier attached to the Kali-to-Ubuntu traffic.

## Why the distinction matters

Snort outputs alerts from packet/rule matches. Random Forest outputs predicted labels for flow records. Their evidence is useful together, but the original experiment does not support a direct metric-equivalent ranking.

## Proposed future hybrid

A future system could mirror the same traffic into Snort and a live flow extractor, forward both outputs to a correlation/SIEM layer, aggregate repetitive packet alerts into incidents, and evaluate both against common event-level ground truth.
